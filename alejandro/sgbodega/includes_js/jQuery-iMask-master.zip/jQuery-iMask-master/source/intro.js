/*!
 * jQuery iMask Plugin v@VERSION
 *
 * Licensed under the MIT License
 * Authors: Mark Kahn
 *          Fabio Zendhi Nagao (http://zend.lojcomm.com.br)
 *
 * Date: @DATE
 */
