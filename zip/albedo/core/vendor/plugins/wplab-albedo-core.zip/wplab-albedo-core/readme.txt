=== WPlab ALbedo Core ===
Contributors: WPlab
Requires at least: 4.8

This plugin provides custom post types and Visual Composer shortcodes for Albedo Premium WordPress Theme

== Description ==

This plugin provides custom post types and Visual Composer shortcodes for Albedo Premium WordPress Theme

== Changelog ==

= 1.0.9 =
* Added compatibility with JetPack Mobile theme

= 1.0.8 =
* Fixed redirect on success in forms

= 1.0.7 =
* Fixed a problem with custom queries in some of Blog shortcodes

= 1.0.6 =
* Fixed a problem with YOAST SEO plugin

= 1.0.5 =
* Fixed Benefits Numeric shortcode custom styles

= 1.0.4 =
* Added more admin labels for VC shortcodes

= 1.0.3 =
* Fixed a bug with "Display only / display except" in portfolio posts shortcode

= 1.0.2 =
* Added auto-updater

= 1.0.1 =
* Fixed custom icon fonts loading problem in a Benefits shortcode

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.2 =
* Added auto-updater

= 1.0.1 =
* Fixed custom icon fonts loading problem in a Benefits shortcode

= 1.0.0 =
* Initial release
