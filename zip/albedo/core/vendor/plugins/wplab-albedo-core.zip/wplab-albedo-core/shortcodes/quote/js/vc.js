(function ( $ ) {

	function wplab_albedo_quote_refresh( elem ) {

    var $iframe = $("#vc_inline-frame"),
    iframeContents = $iframe.contents(),
    contentWindow = $iframe[0].contentWindow,
    $element = elem.$el.find('.shortcode-quote'),
    elementId = $element.attr('id'),
    cssId = 'albedo-custom-css-id-' + elementId;

    iframeContents.find('#' + cssId).remove();
    iframeContents.find("head").append('<!-- auto generated custom css by element / shortcode --><style type="text/css" id="' + cssId + '">' + $element.data('custom-css') + '</style>');

		contentWindow.themeFrontCore.initLazyLoading();

	}

	window.InlineShortcodeView_albedo_quote = window.InlineShortcodeView.extend( {
		render: function () {

			window.InlineShortcodeView_albedo_quote.__super__.render.call( this );
			wplab_albedo_quote_refresh( this );

			return this;
		}
	} );

})( window.jQuery );
