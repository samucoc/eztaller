(function ( $ ) {

	function albedo_portfolio_full_screen_photos_carousel_refresh( element ) {

		var $iframe = $("#vc_inline-frame"),
		iframeContents = $iframe.contents(),
		contentWindow = $iframe[0].contentWindow,
		$element = element.$el.find('.photo-fullscreen-gallery'),
		elementId = $element.attr('id'),
		cssId = 'albedo-custom-css-id-' + elementId;

		contentWindow.themeFrontCore.initLazyLoading();

		if( 'albedo_portfolio_full_screen_photos_carousel_init' in contentWindow ) {
			contentWindow.albedo_portfolio_full_screen_photos_carousel_init();
		} else {
			setTimeout( function() {
				contentWindow.albedo_portfolio_full_screen_photos_carousel_init();
			}, 500 );
		}

	}

	window.InlineShortcodeView_albedo_benefits_filters = window.InlineShortcodeView.extend({
		render: function () {

			window.InlineShortcodeView_albedo_benefits_filters.__super__.render.call( this );
			albedo_portfolio_full_screen_photos_carousel_refresh( this );

		  return this;
		},
		updated: function() {
			_.each(vc.shortcodes.where({
					parent_id: this.model.get("id")
			}), function(model) {
					model.view.parent_view = this, model.view.parentChanged()
			}, this), _.defer(_.bind(function() {
					vc.events.trigger("shortcodeView:updated", this.model), vc.events.trigger("shortcodeView:updated:" + this.model.get("shortcode"), this.model), vc.events.trigger("shortcodeView:updated:" + this.model.get("id"), this.model)
			}, this))

			// wait until element will be fully loaded
			var instance = this;
	    $(document).ajaxStop(function () {
				albedo_portfolio_full_screen_photos_carousel_refresh( instance );
			});

		}
	});

})( window.jQuery );
