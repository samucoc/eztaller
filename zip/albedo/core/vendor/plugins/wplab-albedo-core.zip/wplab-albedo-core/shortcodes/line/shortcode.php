<?php

  /**
    * Line Shortcode
  **/

  // Map VC shortcode
  require_once 'config.php';

  if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Albedo_Line extends WPBakeryShortCode {

      protected function content( $atts, $content = null ) {

        ob_start();
        require plugin_dir_path( __FILE__ ) . '/../../vc_templates/albedo_line.php';
        return ob_get_clean();

      }
    }
  }
