(function ( $ ) {

	function wplab_albedo_contact_form_refresh() {
		var $iframe = $("#vc_inline-frame"),
		contentWindow = $iframe[0].contentWindow;

		if( 'albedo_contact_form_init' in contentWindow ) {
			contentWindow.albedo_contact_form_init();
			contentWindow.themeFrontCore.setupInputForms();
		} else {
			setTimeout( function() {
				contentWindow.albedo_contact_form_init();
				contentWindow.themeFrontCore.setupInputForms();
			}, 500 );
		}

	}

	window.InlineShortcodeView_albedo_contact_form = window.InlineShortcodeViewContainer.extend({
		render: function () {

			window.InlineShortcodeViewContainer.__super__.render.call(this);
			wplab_albedo_contact_form_refresh();

		  return this;
		}
	});

	window.InlineShortcodeView_albedo_contact_form_checkbox = window.InlineShortcodeView.extend( {
		render: function () {

			window.InlineShortcodeView_albedo_contact_form_checkbox.__super__.render.call( this );
			wplab_albedo_contact_form_refresh();

			return this;
		}
	} );

  window.InlineShortcodeView_albedo_contact_form_dropdown = window.InlineShortcodeView.extend( {
		render: function () {

			window.InlineShortcodeView_albedo_contact_form_dropdown.__super__.render.call( this );
			wplab_albedo_contact_form_refresh();

			return this;
		}
	} );

  window.InlineShortcodeView_albedo_contact_form_radio = window.InlineShortcodeView.extend( {
		render: function () {

			window.InlineShortcodeView_albedo_contact_form_radio.__super__.render.call( this );
			wplab_albedo_contact_form_refresh();

			return this;
		}
	} );

})( window.jQuery );
