<?php

vc_map( array(
  'name' => esc_html__( 'Social Icons', 'wplab-albedo-core-plugin' ),
	'base' => 'albedo_social_icons',
  'icon' => $this->plugin_uri . '/assets/shortcode_icons/social-icons.png',
	'category' => esc_html__( 'Content Elements', 'wplab-albedo-core-plugin' ),
	'description' => esc_html__( 'Add social icons', 'wplab-albedo-core-plugin' ),
	'params' => array_merge( $this->cfg['social_profiles'], array(

    /**
     *  Styling tab
    **/
    array(
  		'type' => 'colorpicker',
  		'heading' => esc_html__( 'Icon color', 'wplab-albedo-core-plugin' ),
  		'param_name' => 'icon_color',
  		'value' => '',
  		'group' => esc_html__('Styling', 'wplab-albedo-core-plugin'),
  	),
    array(
  		'type' => 'colorpicker',
  		'heading' => esc_html__( 'Icon Hover Color', 'wplab-albedo-core-plugin' ),
  		'param_name' => 'icon_hover_color',
  		'value' => '',
  		'group' => esc_html__('Styling', 'wplab-albedo-core-plugin'),
  	),
    array(
  		'type' => 'textfield',
  		'heading' => esc_html__( 'Custom font size', 'wplab-albedo-core-plugin' ),
      'description' => esc_html__( 'value in pixels, e.g. 18', 'wplab-albedo-core-plugin' ),
  		'param_name' => 'font_size',
  		'value' => '',
  		'group' => esc_html__('Styling', 'wplab-albedo-core-plugin'),
  	),

    /**
     *  Attributes tab
    **/
    array(
      'type' => 'el_id',
      'heading' => esc_html__( 'Element ID', 'wplab-albedo-core-plugin' ),
      'param_name' => 'el_id',
      'settings' => array(
        'auto_generate' => true,
      ),
      'group' => esc_html__('Attributes', 'wplab-albedo-core-plugin'),
      'description' => esc_html__( 'Unique identifier of this element', 'wplab-albedo-core-plugin' ),
    ),

  ) )
));
