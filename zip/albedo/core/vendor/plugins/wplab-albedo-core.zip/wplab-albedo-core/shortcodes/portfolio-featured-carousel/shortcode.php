<?php

  /**
    * Portfolio Featured Carousel Shortcode
  **/

  // Map VC shortcode
  require_once 'config.php';

  if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Albedo_Portfolio_Featured_Carousel extends WPBakeryShortCode {

      protected function content( $atts, $content = null ) {
        global $wplab_albedo_core_plugin;

        $atts = vc_map_get_attributes( $this->getShortcode(), $atts );

        $attributes = $classes = $wrapper_classes = array();

        $shortcode_id = 'shortcode-' . $atts['el_id'];

    		$postfix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

        /** include swiper carousel2 library styles **/
    		wp_enqueue_style( 'swiper', get_template_directory_uri() . '/css/libs/swiper.min.css', false, _WPLAB_ALBEDO_CACHE_TIME_ );
    		wp_enqueue_script( 'swiper');

    		wp_enqueue_style( 'wplab-albedo-portfolio-featured-carousel', wplab_albedo_utils::locate_uri( '/css/front/css/shortcodes/portfolio_featured_carousel.css'), false, _WPLAB_ALBEDO_CACHE_TIME_ );
        $variable_style = $wplab_albedo_core_plugin->lessify( wplab_albedo_utils::locate_uri( '/css/front/less/shortcodes/portfolio_featured_carousel_variable.less') );
    		wp_enqueue_style( 'wplab-albedo-portfolio-featured-carousel-variable', $variable_style, false, _WPLAB_ALBEDO_CACHE_TIME_ );

    		wp_enqueue_script( 'wplab-albedo-portfolio-featured-carousel', wplab_albedo_utils::locate_uri('/framework-customizations/extensions/shortcodes/shortcodes/portfolio-featured-carousel/static/js/scripts' . $postfix . '.js'), array('jquery'), _WPLAB_ALBEDO_CACHE_TIME_, true );

        $custom_css = '';

    		if( $atts['pagination_color'] <> '' ) {
    			$custom_css .= ' #' . $shortcode_id . ' .swiper-pagination-bullet { background-color: ' . $atts['pagination_color'] . '; }';
    		}

    		if( $atts['pagination_active_color'] <> '' ) {
    			$custom_css .= ' #' . $shortcode_id . ' .swiper-pagination-bullet-active { background-color: ' . $atts['pagination_active_color'] . '; }';
    		}

        if( $custom_css <> '' ) {
          $attributes[] = 'data-custom-css=\'' . $custom_css . '\'';
        }

        ob_start();
        require plugin_dir_path( __FILE__ ) . '/../../vc_templates/albedo_portfolio_featured_carousel.php';
        return ob_get_clean();

      }

    }
  }
