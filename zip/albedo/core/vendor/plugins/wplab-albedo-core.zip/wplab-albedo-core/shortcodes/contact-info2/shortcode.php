<?php

  /**
    * Contact Info 2 Shortcode
  **/

  // Map VC shortcode
  require_once 'config.php';

  if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Albedo_Contact_Info2 extends WPBakeryShortCodesContainer {

      protected function content( $atts, $content = null ) {

        $atts = vc_map_get_attributes( $this->getShortcode(), $atts );

        /** load static stylesheet **/
        wp_enqueue_style( 'wplab-albedo-contact-info', wplab_albedo_utils::locate_uri( '/css/front/css/shortcodes/contact_info.css'), false, _WPLAB_ALBEDO_CORE_CACHE_TIME_ );

        global $wplab_albedo_core_plugin;
        $variable_style = $wplab_albedo_core_plugin->lessify( wplab_albedo_utils::locate_uri( '/css/front/less/shortcodes/contact_info_variable.less') );
        wp_enqueue_style( 'wplab-albedo-contact-info-variable', $variable_style, false, _WPLAB_ALBEDO_CORE_CACHE_TIME_ );

        ob_start();
        require plugin_dir_path( __FILE__ ) . '/../../vc_templates/albedo_contact_info2.php';
        return ob_get_clean();

      }

    }
  }
  if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Albedo_Contact_Info2_Single extends WPBakeryShortCode {
    }
  }
