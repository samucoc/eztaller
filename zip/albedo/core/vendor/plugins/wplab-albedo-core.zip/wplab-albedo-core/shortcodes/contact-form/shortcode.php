<?php

  /**
    * Contact Form Shortcode
  **/

  // Map primary VC shortcode
  require_once 'config.php';

  require_once 'fields/checkbox.php';
  require_once 'fields/dropdown.php';
  require_once 'fields/email.php';
  require_once 'fields/number.php';
  require_once 'fields/radio.php';
  require_once 'fields/recaptcha.php';
  require_once 'fields/text.php';
  require_once 'fields/textarea.php';
  require_once 'fields/url.php';
  require_once 'fields/submit.php';
