<?php

  /**
    * Portfolio Posts Carousel Shortcode
  **/

  // Map VC shortcode
  require_once 'config.php';

  if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Albedo_Portfolio_Posts_Carousel extends WPBakeryShortCode {

      protected function content( $atts, $content = null ) {
        global $wplab_albedo_core_plugin;

        $atts = vc_map_get_attributes( $this->getShortcode(), $atts );

        $attributes = $classes = $wrapper_classes = array();

        $shortcode_id = 'shortcode-' . $atts['el_id'];

    		$postfix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

        /** include swiper carousel2 library styles **/
    		wp_enqueue_style( 'swiper', get_template_directory_uri() . '/css/libs/swiper.min.css', false, _WPLAB_ALBEDO_CACHE_TIME_ );
    		wp_enqueue_script( 'swiper');

    		wp_enqueue_style( 'wplab-albedo-portfolio-posts-carousel', wplab_albedo_utils::locate_uri( '/css/front/css/shortcodes/portfolio_posts_carousel.css'), false, _WPLAB_ALBEDO_CACHE_TIME_ );
        $variable_style = $wplab_albedo_core_plugin->lessify( wplab_albedo_utils::locate_uri( '/css/front/less/shortcodes/portfolio_posts_carousel_variable.less') );
    		wp_enqueue_style( 'wplab-albedo-portfolio-posts-carousel-variable', $variable_style, false, _WPLAB_ALBEDO_CACHE_TIME_ );

    		/** include lightbox **/
    		$js_vars = array();
    		if( filter_var( $atts['display_lightbox_icon'], FILTER_VALIDATE_BOOLEAN ) ) {

    			/** include LightGallery library styles **/
    			wp_enqueue_style( 'lightgallery', get_template_directory_uri() . '/css/libs/lightgallery.min.css', false, _WPLAB_ALBEDO_CACHE_TIME_ );
    			wp_enqueue_style( 'lightgallery-transitions', get_template_directory_uri() . '/css/libs/lg-transitions.min.css', false, _WPLAB_ALBEDO_CACHE_TIME_ );
    			wp_enqueue_script( 'lightgallery');

    			$js_vars = array(
    				'lightboxEffect' => fw_get_db_settings_option( 'lightbox_effect' ),
    				'lightboxEasing' => fw_get_db_settings_option( 'lightbox_easing' ),
    				'lightboxThumbs' => filter_var( fw_get_db_settings_option( 'lightbox_thumbnails' ), FILTER_VALIDATE_BOOLEAN ),
    				'lightboxCaptions' => filter_var( fw_get_db_settings_option( 'lightbox_captions' ), FILTER_VALIDATE_BOOLEAN ),
    				'lightboxFullscreen' => filter_var( fw_get_db_settings_option( 'lightbox_fullscreen' ), FILTER_VALIDATE_BOOLEAN ),
    				'lightboxZoom' => filter_var( fw_get_db_settings_option( 'lightbox_zoom' ), FILTER_VALIDATE_BOOLEAN ),
    				'lightboxDownload' => filter_var( fw_get_db_settings_option( 'lightbox_download' ), FILTER_VALIDATE_BOOLEAN ),
    				'lightboxAutoplay' => filter_var( fw_get_db_settings_option( 'lightbox_autoplay/enabled' ), FILTER_VALIDATE_BOOLEAN ),
    				'lightboxAutoplaySpeed' => absint( fw_get_db_settings_option( 'lightbox_autoplay/yes/speed' ) ),
    			);

    			if( $js_vars['lightboxThumbs'] == true ) {
    				wp_enqueue_script( 'lightgallery-thumb');
    			}
    			if( $js_vars['lightboxFullscreen'] == true ) {
    				wp_enqueue_script( 'lightgallery-fullscreen');
    			}
    			if( $js_vars['lightboxAutoplay'] == true ) {
    				wp_enqueue_script( 'lightgallery-autoplay');
    			}
    			if( $js_vars['lightboxZoom'] == true ) {
    				wp_enqueue_script( 'lightgallery-zoom');
    			}

    		}

    		wp_enqueue_script( 'wplab-albedo-portfolio-posts-carousel', wplab_albedo_utils::locate_uri('/framework-customizations/extensions/shortcodes/shortcodes/portfolio-posts-carousel/static/js/scripts' . $postfix . '.js'), array('jquery'), _WPLAB_ALBEDO_CACHE_TIME_, true );
    		wp_localize_script( 'wplab-albedo-portfolio-posts-carousel', 'wplabAlbedoPortfolioPostsCarousel', $js_vars );

        ob_start();
        require plugin_dir_path( __FILE__ ) . '/../../vc_templates/albedo_portfolio_posts_carousel.php';
        return ob_get_clean();

      }

    }
  }
