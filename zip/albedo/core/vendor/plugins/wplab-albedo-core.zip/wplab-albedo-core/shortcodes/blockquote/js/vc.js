(function ( $ ) {

	function wplab_albedo_blockquote_refresh( elem ) {

    var $iframe = $("#vc_inline-frame"),
    iframeContents = $iframe.contents(),
    contentWindow = $iframe[0].contentWindow,
    $element = elem.$el.find('.shortcode-blockquote'),
    elementId = $element.attr('id'),
    cssId = 'albedo-custom-css-id-' + elementId;

    iframeContents.find('#' + cssId).remove();
    iframeContents.find("head").append('<!-- auto generated custom css by element / shortcode --><style type="text/css" id="' + cssId + '">' + $element.data('custom-css') + '</style>');

	}

	window.InlineShortcodeView_albedo_blockquote = window.InlineShortcodeView.extend( {
		render: function () {

			window.InlineShortcodeView_albedo_blockquote.__super__.render.call( this );
			wplab_albedo_blockquote_refresh( this );

			return this;
		}
	} );

})( window.jQuery );
