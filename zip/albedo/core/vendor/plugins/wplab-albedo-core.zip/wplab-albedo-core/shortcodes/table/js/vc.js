(function ( $ ) {

	function wplab_albedo_table_refresh() {
		var $iframe = $("#vc_inline-frame"),
		contentWindow = $iframe[0].contentWindow;

		contentWindow.themeFrontCore.loadSVG();

	}

	window.InlineShortcodeView_albedo_table = window.InlineShortcodeView.extend({
		render: function () {

			window.InlineShortcodeView_albedo_table.__super__.render.call( this );
			wplab_albedo_table_refresh();

		  return this;
		},
		updated: function() {
			_.each(vc.shortcodes.where({
					parent_id: this.model.get("id")
			}), function(model) {
					model.view.parent_view = this, model.view.parentChanged()
			}, this), _.defer(_.bind(function() {
					vc.events.trigger("shortcodeView:updated", this.model), vc.events.trigger("shortcodeView:updated:" + this.model.get("shortcode"), this.model), vc.events.trigger("shortcodeView:updated:" + this.model.get("id"), this.model)
			}, this))

			// wait until element will be fully loaded
	    $(document).ajaxStop(function () {
				wplab_albedo_table_refresh();
			});

		}
	});

})( window.jQuery );
