<?php

vc_map( array(
  'name' => esc_html__( 'Contact Info', 'wplab-albedo-core-plugin' ),
	'base' => 'albedo_contact_info',
  'icon' => $this->plugin_uri . '/assets/shortcode_icons/contact-info-01.png',
	'category' => esc_html__( 'Content Elements', 'wplab-albedo-core-plugin' ),
	'description' => esc_html__( 'Add contact information', 'wplab-albedo-core-plugin' ),
	'params' => array(

    array(
      'type' => 'textarea',
      'heading' => esc_html__( 'Address', 'wplab-albedo-core-plugin' ),
      'param_name' => 'address',
      'admin_label' => true,
      'value' => '',
    ),
    array(
      'type' => 'textarea',
      'heading' => esc_html__( 'Phone', 'wplab-albedo-core-plugin' ),
      'param_name' => 'phone',
      'admin_label' => true,
      'value' => '',
    ),
    array(
      'type' => 'textarea',
      'heading' => esc_html__( 'E-mail', 'wplab-albedo-core-plugin' ),
      'param_name' => 'email',
      'admin_label' => true,
      'value' => '',
    ),

  )
));
