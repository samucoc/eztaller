<?php

vc_map( array(
  'name' => esc_html__( 'Contact Info 2', 'wplab-albedo-core-plugin' ),
	'base' => 'albedo_contact_info2',
  'icon' => $this->plugin_uri . '/assets/shortcode_icons/contact-info-02.png',
	'category' => esc_html__( 'Content Elements', 'wplab-albedo-core-plugin' ),
	'description' => esc_html__( 'Add contact information', 'wplab-albedo-core-plugin' ),
  'as_parent' => array( 'only' => 'albedo_contact_info2_single' ),
  'content_element' => true,
  'is_container' => true,
  'show_settings_on_create' => false,
  'js_view' => 'VcColumnView',
	'params' => array(

    array(
      'type' => 'dropdown',
      'heading' => esc_html__('Columns', 'wplab-albedo-core-plugin'),
      'param_name' => 'cols',
      'save_always' => true,
      'value' => array(
        '4' => '4',
        '3' => '3',
        '2' => '2',
        '1' => '1',
      ),
    ),

  )
));

vc_map( array(
  'name' => esc_html__( 'Contact Information', 'wplab-albedo-core-plugin' ),
	'base' => 'albedo_contact_info2_single',
  'content_element' => true,
  'icon' => $this->plugin_uri . '/assets/shortcode_icons/contact-info-02.png',
  'as_child' => array( 'only' => 'albedo_contact_info2' ),
	'params' => array(

    array(
      'type' => 'textfield',
      'heading' => esc_html__( 'Header', 'wplab-albedo-core-plugin' ),
      'param_name' => 'header',
      'admin_label' => true,
      'value' => '',
    ),
    array(
      'type' => 'textfield',
      'heading' => esc_html__( 'Address title', 'wplab-albedo-core-plugin' ),
      'param_name' => 'address_title',
      'value' => esc_html__( 'Address', 'wplab-albedo-core-plugin' ) . ':',
    ),
    array(
      'type' => 'textarea',
      'heading' => esc_html__( 'Address', 'wplab-albedo-core-plugin' ),
      'param_name' => 'address',
      'value' => '',
    ),
    array(
      'type' => 'textfield',
      'heading' => esc_html__( 'Phone title', 'wplab-albedo-core-plugin' ),
      'param_name' => 'phone_title',
      'value' => esc_html__( 'Phone', 'wplab-albedo-core-plugin' ) . ':',
    ),
    array(
      'type' => 'textarea',
      'heading' => esc_html__( 'Phone', 'wplab-albedo-core-plugin' ),
      'param_name' => 'phone',
      'value' => '',
    ),
    array(
      'type' => 'textfield',
      'heading' => esc_html__( 'Email title', 'wplab-albedo-core-plugin' ),
      'param_name' => 'email_title',
      'value' => esc_html__( 'Email', 'wplab-albedo-core-plugin' ) . ':',
    ),
    array(
      'type' => 'textarea',
      'heading' => esc_html__( 'Email', 'wplab-albedo-core-plugin' ),
      'param_name' => 'email',
      'value' => '',
    ),

  )
));
