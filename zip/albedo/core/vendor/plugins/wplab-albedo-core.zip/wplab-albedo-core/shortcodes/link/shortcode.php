<?php

  /**
    * Link Shortcode
  **/

  // Map VC shortcode
  require_once 'config.php';

  if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Albedo_Link extends WPBakeryShortCode {

      protected function content( $atts, $content = null ) {

        $atts = vc_map_get_attributes( $this->getShortcode(), $atts );

        if( filter_var( $atts['typed_animation'], FILTER_VALIDATE_BOOLEAN ) ) {
    			wp_enqueue_script( 'typed');
    		}

        ob_start();
        require plugin_dir_path( __FILE__ ) . '/../../vc_templates/albedo_link.php';
        return ob_get_clean();

      }

    }
  }
