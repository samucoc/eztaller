<?php

  /**
    * Column Shortcode
  **/

  require_once 'config.php';
