(function ( $ ) {
	window.InlineShortcodeView_albedo_progress_bar = window.InlineShortcodeView.extend( {
		render: function () {

			window.InlineShortcodeView_albedo_progress_bar.__super__.render.call( this );

			var $iframe = $("#vc_inline-frame"),
			iframeContents = $iframe.contents(),
			$element = this.$el.find('.progress-bar'),
			elementId = $element.attr('id'),
			cssId = 'albedo-custom-css-id-' + elementId;

			iframeContents.find('#' + cssId).remove();
      iframeContents.find("head").append('<!-- auto generated custom css by element / shortcode --><style type="text/css" id="' + cssId + '">' + $element.data('custom-css') + '</style>');

			return this;
		}
	} );
})( window.jQuery );
