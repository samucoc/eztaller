<?php

vc_map( array(
  'name' => esc_html__( 'Video', 'wplab-albedo-core-plugin' ),
	'base' => 'albedo_video',
  'icon' => $this->plugin_uri . '/assets/shortcode_icons/video.png',
	'category' => esc_html__( 'Media', 'wplab-albedo-core-plugin' ),
	'description' => esc_html__( 'Add a video', 'wplab-albedo-core-plugin' ),
	'params' => array(

    array(
      'type' => 'textfield',
      'heading' => esc_html__( 'Video URL', 'wplab-albedo-core-plugin' ),
      'description' => esc_html__( 'Insert Video URL to embed this video', 'wplab-albedo-core-plugin' ),
      'param_name' => 'url',
      'value' => '',
    ),

  )
));

if ( class_exists( 'WPBakeryShortCode' ) ) {
  class WPBakeryShortCode_Albedo_Video extends WPBakeryShortCode {
  }
}
