<?php

  /**
    * Google Map Shortcode
  **/

  // Map VC shortcode
  require_once 'config.php';

  if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Albedo_Google_Map extends WPBakeryShortCode {

      protected function content( $atts, $content = null ) {

        $atts = vc_map_get_attributes( $this->getShortcode(), $atts );

        ob_start();
        require plugin_dir_path( __FILE__ ) . '/../../vc_templates/albedo_google_map.php';
        return ob_get_clean();

      }
    }
  }
