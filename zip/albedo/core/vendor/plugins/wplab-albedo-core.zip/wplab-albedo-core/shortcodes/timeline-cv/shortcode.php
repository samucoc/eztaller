<?php

  /**
    * Timeline / CV Shortcode
  **/

  // Map VC shortcode
  require_once 'config.php';

  if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Albedo_Timeline_Cv extends WPBakeryShortCode {

      protected function content( $atts, $content = null ) {

        /** load static stylesheet **/
    		wp_enqueue_style( 'wplab-albedo-timeline-cv', wplab_albedo_utils::locate_uri( '/css/front/css/shortcodes/timeline_cv.css'), false, _WPLAB_ALBEDO_CORE_CACHE_TIME_ );

        global $wplab_albedo_core_plugin;
        $variable_style = $wplab_albedo_core_plugin->lessify( wplab_albedo_utils::locate_uri( '/css/front/less/shortcodes/timeline_cv_variable.less') );
        wp_enqueue_style( 'wplab-albedo-timeline-cv-variable', $variable_style, false, _WPLAB_ALBEDO_CORE_CACHE_TIME_ );

        ob_start();
        require plugin_dir_path( __FILE__ ) . '/../../vc_templates/albedo_timeline_cv.php';
        return ob_get_clean();

      }

    }
  }
