<?php

$icon = '';
if( $atts['icon'] <> '' ) {
	$icon = '<i class="' . $atts['icon'] . '"></i>';
}

$icon_left = $icon_right = '';
if( $atts['icon_position'] == 'right' ) {
	$icon_right = $icon;
	$css_classes[] = 'icon-position-right';
} else {
	$icon_left = $icon;
	$css_classes[] = 'icon-position-left';
}

/**
 * Button label
 **/

if( $atts['label'] <> '' ) {
	$css_classes = implode( ' ', $css_classes );
	$attributes = implode( ' ', $attributes );

	if( isset( $atts['align'] ) && $atts['align'] <> '' ) {
		echo '<div class="button-align-' . esc_attr( $atts['align'] ) . '">';
	}

	echo "<a {$attributes} class=\"{$css_classes}\">{$icon_left}{$atts['label']}{$icon_right}</a>";

	if( isset( $atts['align'] ) && $atts['align'] <> '' ) {
		echo '</div>';
	}

}
