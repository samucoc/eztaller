<?php $atts = vc_map_get_attributes( $this->getShortcode(), $atts ); ?>
<div class="theme-accordion style-<?php echo $atts['style']; ?>"><?php echo wpb_js_remove_wpautop( $content ); ?></div>
<?php

wp_enqueue_style( 'wplab-albedo-accordion' );

global $wplab_albedo_core_plugin;
$variable_style = $wplab_albedo_core_plugin->lessify( wplab_albedo_utils::locate_uri( '/css/front/less/shortcodes/accordion_variable.less') );
wp_enqueue_style( 'wplab-albedo-accordion-variable', $variable_style, false, _WPLAB_ALBEDO_CORE_CACHE_TIME_ );

wp_enqueue_script( 'wplab-albedo-accordion' );
