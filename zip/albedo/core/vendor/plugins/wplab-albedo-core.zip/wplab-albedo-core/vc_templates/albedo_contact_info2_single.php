<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

global $wplab_albedo_shortcode_contact_info2, $wplab_albedo_shortcode_contact_info2_counter;

if( $wplab_albedo_shortcode_contact_info2_counter % $wplab_albedo_shortcode_contact_info2['_cols'] == 0 ): ?>
<div class="row">
<?php endif; $wplab_albedo_shortcode_contact_info2_counter++; ?>

<div class="item col-md-<?php echo $wplab_albedo_shortcode_contact_info2['_column']; ?>">

  <div class="inside">
    <?php if( $atts['header'] <> '' ): ?>

      <h4>
        <?php echo wp_kses_post( $atts['header'] ); ?>
      </h4>

    <?php endif; ?>

    <dl>
    <?php if( $atts['address'] <> '' ): ?>
      <dt><?php echo wp_kses_post( $atts['address_title'] ); ?></dt>
      <dd><?php echo str_replace("<br /><br />", '<br />', nl2br( $atts['address'] ) ); ?></dd>
    <?php endif; ?>

    <?php if( $atts['phone'] <> '' ): ?>
      <dt><?php echo wp_kses_post( $atts['phone_title'] ); ?></dt>
      <dd><?php echo str_replace("<br /><br />", '<br />', nl2br( $atts['phone'] ) ); ?></dd>
    <?php endif; ?>

    <?php if( $atts['email'] <> '' ): ?>
      <dt><?php echo wp_kses_post( $atts['email_title'] ); ?></dt>
      <dd><?php echo str_replace("<br /><br />", '<br />', nl2br( wplab_albedo_utils::emailize( $atts['email'] ) ) ); ?></dd>
    <?php endif; ?>
    </dl>
  </div>
</div>

<?php if( $wplab_albedo_shortcode_contact_info2_counter % $wplab_albedo_shortcode_contact_info2['_cols'] == 0 ): ?>
</div>
<?php endif;
