<?php
	$period = isset( $table_data['features']['period'][$package_id][0] ) ? $table_data['features']['period'][$package_id][0] : '';
	$price = isset( $table_data['features']['price'][$package_id][0] ) ? $table_data['features']['price'][$package_id][0] : '';
	$details = isset( $table_data['features']['details'][$package_id][0] ) ? $table_data['features']['details'][$package_id][0] : '';
	$button_text = isset( $table_data['features']['button_text'][$package_id][0] ) ? $table_data['features']['button_text'][$package_id][0] : '';
	$button_url = isset( $table_data['features']['button_url'][$package_id][0] ) ? $table_data['features']['button_url'][$package_id][0] : '';
	$button_style = isset( $table_data['features']['button_style'][$package_id][0] ) ? $table_data['features']['button_style'][$package_id][0] : '';
?>

<?php if( $price <> '' ): ?>
<div class="fw-pricing-row">
	<span><?php echo $price; ?></span>
	<?php if( $period <> '' ): ?>
		<small><?php echo $period; ?></small>
	<?php endif; ?>
</div>
<?php endif; ?>

<?php if( $package_name <> '' ): ?>
<div class="fw-heading-row">
	<span><?php echo $package_name; ?></span>
</div>
<?php endif; ?>

<?php if( $details <> '' ): ?>
<div class="fw-default-row">
	<?php echo $details; ?>
</div>
<?php endif; ?>

<?php if( isset( $table_data['features']['user_features_names'] ) && !empty( $table_data['features']['user_features_names'] ) ): ?>

	<?php foreach( $table_data['features']['user_features_names'] as $feature_key => $feature_title ): ?>
		<div class="fw-default-row">
			<?php if( isset( $table_data['features']['user_features_values'][$package_id][$feature_key] ) && !empty( $table_data['features']['user_features_values'][$package_id][$feature_key] ) ): ?>
				<?php echo $table_data['features']['user_features_values'][$package_id][$feature_key]; ?>
			<?php endif; ?>
			<?php echo $feature_title[0]; ?>
		</div>
	<?php endforeach; ?>

<?php endif; ?>

<?php if( $button_text <> '' ): ?>
<div class="fw-button-row">
	<div class="button-align-center">
		<a href="<?php echo $button_url; ?>" target="_blank" class="button size-medium style-<?php echo $button_style; ?>"><?php echo $button_text; ?></a>
	</div>
</div>
<?php endif;
