<?php

echo '<div class="wproto-mailchimp">';
echo do_shortcode( '[mc4wp_form id="' . $atts['form_id'] . '"]' );
echo '</div>';
