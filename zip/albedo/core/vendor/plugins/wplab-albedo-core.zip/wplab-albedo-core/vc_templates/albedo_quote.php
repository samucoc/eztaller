<blockquote class="shortcode-quote style-<?php echo esc_attr( $atts['style'] ); ?> <?php echo implode(' ', $classes); ?>" <?php echo implode( ' ', $attributes ); ?>>

	<?php if( $atts['text'] <> '' ): ?>
	<div class="text wow <?php echo esc_attr( $atts['text_animation_effect']); ?>" data-wow-delay="<?php echo esc_attr( $atts['text_animation_delay']); ?>">
		<?php echo wp_kses_post( $atts['text'] ); ?>
	</div>
	<?php endif; ?>

	<?php
		if( $atts['sign_image'] <> '' ):
  		$signature = wp_get_attachment_url( $atts['sign_image'] );
	?>
	<div class="signature wow <?php echo esc_attr( $atts['sign_animation_effect']); ?>" data-wow-delay="<?php echo esc_attr( $atts['sign_animation_delay']); ?>">
		<?php echo wplab_albedo_media::image( $signature, null, null, true, true, $signature ); ?>
	</div>
	<?php endif; ?>

	<?php if( $atts['author'] <> '' ): ?>
	<div class="author wow <?php echo esc_attr( $atts['author_animation_effect']); ?>" data-wow-delay="<?php echo esc_attr( $atts['author_animation_delay']); ?>">
		<?php echo wp_kses_post( $atts['author'] ); ?>
	</div>
	<?php endif; ?>

	<?php if( $atts['position'] <> '' ): ?>
	<div class="position wow <?php echo esc_attr( $atts['position_animation_effect']); ?>" data-wow-delay="<?php echo esc_attr( $atts['position_animation_delay']); ?>">
		<?php echo wp_kses_post( $atts['position'] ); ?>
	</div>
	<?php endif; ?>

</blockquote>
