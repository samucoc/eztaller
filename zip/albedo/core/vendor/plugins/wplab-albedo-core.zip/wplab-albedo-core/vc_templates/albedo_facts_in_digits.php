<div class="facts-in-digits <?php echo implode(' ', $classes); ?>" <?php echo implode( ' ', $attributes ); ?>>

  <?php echo wpb_js_remove_wpautop( $content ); ?>

</div>
