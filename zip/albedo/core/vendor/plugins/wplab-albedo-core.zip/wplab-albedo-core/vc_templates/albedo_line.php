<?php
  $atts = vc_map_get_attributes( $this->getShortcode(), $atts );

  $class = $style = '';

  if( $atts['line_color'] <> '' ) {
    $class = 'bg-color-' . $atts['line_color'];
  }

  if( $atts['custom_color'] <> '' ) {
    $style .= 'background-color: ' . $atts['custom_color'] . ';';
  }

  if( $atts['corners_radius'] <> '' ) {
    $style .= ' border-radius: ' . $atts['corners_radius'] . 'px;';
  }

  if( $atts['max_width'] <> '' ) {
    $style .= ' max-width: ' . $atts['max_width'] . ';';
  }

  if( $atts['margins'] <> '' ) {
    $style .= ' margin-top: ' . $atts['margins'] . ';';
    $style .= ' margin-bottom: ' . $atts['margins'] . ';';
  }
?>
<div class="fw-divider-line"><hr class="<?php echo esc_attr( $class ); ?>" style="<?php echo esc_attr( $style ); ?>" /></div>
