<p <?php echo implode( ' ', $attributes ); ?> class="shortcode-social-icons">
<?php
global $wplab_albedo_core_plugin;
foreach( $wplab_albedo_core_plugin->cfg['social_icons'] as $k=>$v ):

	if( isset( $atts[ $k ] ) && $atts[ $k ] <> '' ) {
		echo '<a href="' . esc_attr( $atts[ $k ] ) . '" target="_blank"><i class="' . esc_attr( $wplab_albedo_core_plugin->cfg['social_icons'][ $k ] ) . '"></i></a>';
	}

endforeach;

?>
</p>
