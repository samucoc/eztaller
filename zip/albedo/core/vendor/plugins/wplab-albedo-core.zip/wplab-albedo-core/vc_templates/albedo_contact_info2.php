<?php
  $atts['_cols'] = absint( $atts['cols'] );
  $atts['_column'] = 12/$atts['_cols'];
  global $wplab_albedo_shortcode_contact_info2, $wplab_albedo_shortcode_contact_info2_counter;
  $wplab_albedo_shortcode_contact_info2 = $atts;
  $wplab_albedo_shortcode_contact_info2_counter = 0;
?>
<div class="contact-info style-grid">

  <?php echo wpb_js_remove_wpautop( $content ); ?>

  <?php if( $wplab_albedo_shortcode_contact_info2_counter % $atts['_cols'] != 0 ): ?>
  </div>
  <?php endif; ?>

</div>
<?php
  unset( $wplab_albedo_shortcode_contact_info2 );
  unset( $wplab_albedo_shortcode_contact_info2_counter );
