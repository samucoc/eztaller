<?php $atts = vc_map_get_attributes( $this->getShortcode(), $atts ); ?>
<?php
  if( isset( $atts['align'] ) && $atts['align'] <> '' ) {
    echo '<div class="button-align-' . esc_attr( $atts['align'] ) . '">';
  }
?>
<a id="<?php echo esc_attr( $atts['el_id'] ); ?>" href="javascript:;" class="button size-<?php echo esc_attr( $atts['size'] ); ?> style-<?php echo esc_attr( $atts['submit_style'] ); ?> form-builder-submit"><?php echo wp_kses_post( $atts['submit_button_text'] ); ?></a>
<?php
  if( isset( $atts['align'] ) && $atts['align'] <> '' ) {
    echo '</div>';
  }
?>
