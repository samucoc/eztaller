<?php
/**
 * @var $atts
 */

$title = $atts['title'];
$title = preg_replace("/\[(.+?)\](.+?)\[\/(.+?)\]/is", '<span class="$1">$2</span>', $title );
$title = preg_replace("/\{(.+?)\}(.+?)\{\/(.+?)\}/is", '<span class="$1">$2</span>', $title );
$title = str_replace("[br]", '<br/>', $title );
$title = str_replace("{br}", '<br/>', $title );
$title = nl2br( $title );
$title = str_replace("<br /><br />", '<br />', $title );

/**
 * Build a header
 **/
$classes = implode( ' ', $classes );
$attributes = implode( ' ', $attributes );

echo "<{$atts['heading']} class=\"{$classes}\" {$attributes}>{$title}</{$atts['heading']}>";
