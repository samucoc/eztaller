<?php
  global $wplab_albedo_shortcode_contact_form, $wplab_albedo_shortcode_contact_form_captcha;
  $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
  $wplab_albedo_shortcode_contact_form_captcha = true;
  $_SESSION['albedo_contact_form' . $wplab_albedo_shortcode_contact_form['el_id'] ]['captcha_secret'] = $atts['secret_key'];
?>
<div class="form-builder-item">
  <div class="field-recaptcha">
    <?php if( $atts['label'] <> '' ): ?>
      <label><?php echo wp_kses_post( $atts['label'] ); ?></label>
    <?php endif; ?>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <div class="g-recaptcha" data-sitekey="<?php echo esc_attr( $atts['site_key'] ); ?>"></div>
  </div>
</div>
