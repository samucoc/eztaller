<?php $atts = vc_map_get_attributes( $this->getShortcode(), $atts ); ?>
<div class="item">
  <h4 class="toggle-header">
    <?php echo $atts['title']; ?>
  </h4>
  <div class="toggle-content">
    <?php echo $atts['text']; ?>
  </div>
</div>
