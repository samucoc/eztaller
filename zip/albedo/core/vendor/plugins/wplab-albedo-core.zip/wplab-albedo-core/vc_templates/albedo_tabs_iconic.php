<?php $atts = vc_map_get_attributes( $this->getShortcode(), $atts ); ?>
<div class="theme-iconic-tabs" data-responsive-break="<?php echo esc_attr( $atts['responsive_break'] ); ?>">
  <div class="tabs">
    <?php echo wpb_js_remove_wpautop( $content ); ?>
  </div>
</div>
