<?php $atts = vc_map_get_attributes( $this->getShortcode(), $atts ); ?>
<div class="theme-tabs tabs-style-<?php echo esc_attr( $atts['style'] ); ?> tabs-type-<?php echo esc_attr( $atts['type'] ); ?>" data-responsive-break="<?php echo esc_attr( $atts['responsive_break'] ); ?>">
  <div class="tabs">
    <?php echo wpb_js_remove_wpautop( $content ); ?>
  </div>
</div>
