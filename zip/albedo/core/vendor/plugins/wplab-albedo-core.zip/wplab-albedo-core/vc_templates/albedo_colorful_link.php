<a <?php echo implode(' ', $attributes ); ?> class="shortcode-colorful-link <?php echo implode( ' ', $classes ); ?>">
	<div class="flexbox">
		<div class="flex-item">
			<?php echo wp_kses_post( $atts['text'] ); ?>
		</div>
	</div>
</a>
