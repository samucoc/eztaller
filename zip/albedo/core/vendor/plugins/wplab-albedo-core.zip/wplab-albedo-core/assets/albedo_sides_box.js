!function($) {
	$('body').on( 'change keyup blur', 'input.albedo-sides-box', function(e){
		e.preventDefault();

		var $input = $(this),
		$allInputs = $input.parent().find('.albedo-sides-box'),
		values = $allInputs.map(function(idx, elem) {
			return $(elem).val();
		}).get(),
		$val_input = $input.parent().find('.albedo-sides-box-value');

		$val_input.val( values.join('|') );

	});
}(window.jQuery);
