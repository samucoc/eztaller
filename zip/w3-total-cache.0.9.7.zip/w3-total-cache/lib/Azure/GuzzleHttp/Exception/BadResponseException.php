<?php
namespace GuzzleHttp\Exception;

/**
 * Exception when an HTTP error occurs (4xx or 5xx error)
 */
class BadResponseException extends RequestException {}
