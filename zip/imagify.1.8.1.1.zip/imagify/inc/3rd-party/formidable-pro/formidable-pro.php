<?php
defined( 'ABSPATH' ) || die( 'Cheatin\' uh?' );

if ( class_exists( 'FrmProEddController' ) ) :

	Imagify_Formidable_Pro::get_instance()->init();

endif;
