These icons are from Icojam (http://www.icojam.com)

Onebit icons

Ammount of icons:
105

File Types:
.png