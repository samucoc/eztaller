<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PermissionsRoles extends Model
{
    protected $table = 'permission_role';
}
