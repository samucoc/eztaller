<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Arrendatario extends Model
{
    protected $table = 'arrendatarios';
}
