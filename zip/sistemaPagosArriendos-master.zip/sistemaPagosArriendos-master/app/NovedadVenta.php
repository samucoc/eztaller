<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NovedadVenta extends Model
{
    protected $table = 'novedadesVentas';
}
