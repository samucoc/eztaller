<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DatosComprador extends Model
{
    protected $table = 'datos_comprador';
}
