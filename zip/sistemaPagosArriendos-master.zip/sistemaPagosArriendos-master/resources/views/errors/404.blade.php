@extends('layouts.app')

@extends('errors::layout')

@section('title', '404')

@section('message', 'No se encuentra esa URL')