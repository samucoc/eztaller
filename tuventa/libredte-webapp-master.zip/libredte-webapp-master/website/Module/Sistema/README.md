Módulo Sistema
==============

Como el mantenedor de actividades económicas es parte de la extensión
[sowerphp/empresa](https://github.com/SowerPHP/extension-empresa) y esta
aplicación no la usa, se ha copiado aquí dicho mantenedor desde la extensión.
