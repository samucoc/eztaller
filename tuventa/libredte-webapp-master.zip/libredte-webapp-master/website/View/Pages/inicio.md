LibreDTE: Aplicación web
========================

LibreDTE es un proyecto que tiene por objetivo proveer facturación electrónica
libre para Chile.

Esta aplicación web utiliza la
[biblioteca PHP LibreDTE](https://github.com/LibreDTE/libredte-lib) y el
[módulo Dte](https://github.com/LibreDTE/libredte-sowerphp) del framework
[SowerPHP](http://sowerphp.org).

Contacto y redes sociales
-------------------------

- Sitio web: <https://libredte.cl>
- Twitter: <https://twitter.com/LibreDTE>
- Facebook: <https://www.facebook.com/LibreDTE>
- Google+: <https://plus.google.com/u/0/101078963971350176990/about>
- Linkedin: <https://www.linkedin.com/grp/home?gid=8403251>
- Youtube: <https://www.youtube.com/channel/UCnh5duQUXmo4l8AD28PakiQ>
